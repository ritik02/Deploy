$(document).ready(function(){
    $('.tooltipped').tooltip();
});
