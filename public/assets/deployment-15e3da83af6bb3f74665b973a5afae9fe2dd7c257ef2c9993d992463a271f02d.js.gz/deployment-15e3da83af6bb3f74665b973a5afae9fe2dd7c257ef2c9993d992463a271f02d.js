$(document).ready(function(){
	$('.modal').modal();
});
function button_click(id){
	$('.modal').modal('open');
}
function close_click(){
	$('.modal').modal('close');
}
;
